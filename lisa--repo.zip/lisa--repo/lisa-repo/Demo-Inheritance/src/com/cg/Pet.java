package com.cg;

public interface Pet {
/*	public Pet(){
		
	}
*/	
	
	public boolean beFriendly();/*{
		
	}*/
	
	abstract void play();
	
	final int MAX=88;
	
	
	
	
	
	
}
