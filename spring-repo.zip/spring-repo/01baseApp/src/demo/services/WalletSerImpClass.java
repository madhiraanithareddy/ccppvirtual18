package demo.services;

import demo.beans.Customer;
import demo.beans.Wallet;
import demo.repo.Repository;
import demo.repo.RepositoryImpClass;


public class WalletSerImpClass implements WalletService {
    Repository repo;
	
	public WalletSerImpClass(Repository repo) {
		super();
		this.repo = repo;
	}
	@Override
	public Customer createAccount(String name, String mobileNumber, float amount) {
		
		Customer cust = new Customer();
		Wallet wallet = new Wallet();
		cust.setName(name);
		cust.setMobileNumber(mobileNumber);
		wallet.setBalance(amount);
		cust.setWallet(wallet);
		repo.save(cust);
		return null;
	}
	
	
	
	

	@Override
	public Customer showBalance(String mobileNumber) {
		return repo.findOne(mobileNumber);
	}
	
	
	
	
	@Override
	public Customer depositAmount(String mobileNumber, float addamount) {
		Customer customer;
		customer=repo.findOne(mobileNumber);
		Wallet wallet;
		wallet=customer.getWallet();
		wallet.setBalance(addamount + wallet.getBalance());
		repo.save(customer);
		return customer;
		
	
		
	}
	
	@Override
	public Customer withdrawAmount(String mobileNumber, float amount) {
		Customer customer;
		customer=repo.findOne(mobileNumber);
		Wallet wallet;
		wallet=customer.getWallet();
		if(amount <= wallet.getBalance()){
			wallet.setBalance( wallet.getBalance() - amount );
		}
		
		repo.save(customer);
		return customer;
	}

	

}
