package demo.services;

import demo.beans.Customer;
import demo.beans.Wallet;

public interface WalletService {
	//Customer customer;
//	Wallet wallet;
	
	 public Customer createAccount(String name,String mobileNumber,float amount);
		
	
	 public Customer showBalance(String mobileNumber);
	 public Customer depositAmount(String mobileNumber,float amount);
	 public Customer withdrawAmount(String mobileNumber,float amount);
}
