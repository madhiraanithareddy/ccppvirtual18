 package demo.repo;

import java.util.HashMap;
import java.util.Map;

import demo.beans.Customer;

public class RepositoryImpClass implements Repository {
	Map<String,Customer> data; 
	public RepositoryImpClass(Map<String, Customer> data) {
		super();
		this.data = data;
	}

	@Override
	public boolean save(Customer c) {
		data.put(c.getMobileNumber(), c);
		return false;
	}

	

	@Override
	public Customer findOne(String mobileNumber) {
		return data.get(mobileNumber);
	}

}

