package demo.repo;

import demo.beans.Customer;

public interface Repository {
	public boolean save(Customer c);
	Customer findOne(String mobileNumber);
}
