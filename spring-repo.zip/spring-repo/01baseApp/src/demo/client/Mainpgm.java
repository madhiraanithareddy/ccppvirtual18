package demo.client;

import java.util.HashMap;
import java.util.Map;

import demo.beans.Customer;
import demo.repo.Repository;
import demo.repo.RepositoryImpClass;
import demo.services.WalletService;
import demo.services.WalletSerImpClass;

public class Mainpgm {
	public static void main(String[] args) {
		
		Map<String, Customer> data = new HashMap<>();
		
		
		Repository repo = new RepositoryImpClass(data);
		WalletService service = new WalletSerImpClass(repo);
		
		
		service.createAccount("Anitha", "9441683726", 50000);
		service.createAccount("Mounika", "9494638343", 35000);
		service.createAccount("srilatha", "949403609", 40000);
		service.createAccount("Rangareddy", "9440283726", 750000);
		service.createAccount("Phani", "9966233080", 950000);
		System.out.println(service.showBalance("9441683726"));
		service.depositAmount("9441683726", 1);
		System.out.println(service.showBalance("9441683726"));
		service.withdrawAmount("9441683726", 50000);
		System.out.println(service.showBalance("9441683726"));
		//System.out.println();
		//System.out.println(service.showBalance("9441683726"));
		
		
		
	}

}
