package com.cg;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FourthServlet extends HttpServlet{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FourthServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//super.doGet(request, response);
		
		
		PrintWriter out = response.getWriter();
		
		
		//	PrintWriter out = response.getWriter();
					out.println("<html><body><h2>");
					out.println("<form action=\"FourthServlet\" >");
					String firstname=request.getParameter("firstname");
					String lastname=request.getParameter("lastname");
					String state=request.getParameter("state");
					String city=request.getParameter("city");
					String phone=request.getParameter("phone");
					String email=request.getParameter("email");
					
					out.println("Firstname :"+firstname+"<br>");
					out.println("Lastname :"+lastname+"<br>");
					out.println("State :"+state+"<br>");
					out.println("City :"+city+"<br>");
					out.println("Phone :"+phone+"<br>");
					out.println("Email :"+email+"<br>");
					
				//	out.println("<input type=\"submit\">");
					out.println("</form></h2></body></html>");  
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request,response);

	  }
}
