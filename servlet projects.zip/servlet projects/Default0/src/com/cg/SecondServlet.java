package com.cg;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SecondServlet extends HttpServlet{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SecondServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//super.doGet(request, response);
		
		
		PrintWriter out = response.getWriter();
		
		
		//	PrintWriter out = response.getWriter();
					out.println("<html><body><h2>");
					out.println("<form action=\"ThirdServlet\" >");
					String firstname=request.getParameter("firstname");
					String lastname=request.getParameter("lastname");
					out.println("Firstname :"+firstname+"<br>");
					out.println("Lastname :"+lastname+"<br>");
					out.println("state <input name=\"state\" type=\"text\"><br>");
					out.println("city <input name=\"city\" type=\"text\"><br>");
					out.println("<input type=\"submit\">");
					out.println("</form></h2></body></html>");  
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request,response);

	  }
}
