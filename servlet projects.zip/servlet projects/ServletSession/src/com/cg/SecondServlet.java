package com.cg;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class SecondServlet extends HttpServlet{
	
	
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		
		
					out.println("<html><body><h2>");
					out.println("<form action=\"ThirdServlet\" >");
					String firstname=request.getParameter("firstname");
					String lastname=request.getParameter("lastname");
					session.setAttribute("firstname",firstname);
					session.setAttribute("lastname",lastname);
					out.println("Firstname :"+firstname+"<br>");
					out.println("Lastname :"+lastname+"<br>");
					out.println("state <input name=\"state\" type=\"text\"><br>");
					out.println("city <input name=\"city\" type=\"text\"><br>");
					out.println("<input type=\"submit\">");
					out.println("</form></h2></body></html>");  
		
		
			//		session.setAttribute(firstname,firstname);
			//		session.setAttribute(lastname,lastname);
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request,response);

	  }
	
	}
	
	

