package com.cg;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ThirdServlet extends HttpServlet{
	
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		PrintWriter out = response.getWriter();
		
		
		   
					out.println("<html><body><h2>");
					out.println("<form action=\"FourthServlet\" >");
		//			HttpSession session = request.getSession();
		//			String firstname= (String) session.getAttribute("firstname");
		//			String lastname= (String) session.getAttribute("lastname");
					String firstname=request.getParameter("firstname");
					String lastname=request.getParameter("lastname");
					String state=request.getParameter("state");
					String city=request.getParameter("city");
					
					out.println("Firstname : <input type='text' readonly name='firstname' value="  +firstname+">");
					out.println("<br>");
					out.println("Lastname : <input type='text' readonly name='lastname' value="  +lastname+">");
					out.println("<br>");
					out.println("State : <input type='text' readonly name='state' value="  +state+">");
					out.println("<br>");
					out.println("City : <input type='text' readonly name='city' value="  +city+">");
					out.println("<br>");
					out.println("phone.no <input  name=\"phone\" type=\"text\"><br>");
					out.println("email-id <input  name=\"email\" type=\"text\"><br>");
					out.println("<input type=\"submit\">");
					out.println("</form></h2></body></html>"); 
			//		session.setAttribute("state",state);
			//		session.setAttribute("city",city);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request,response);

	  }
}
