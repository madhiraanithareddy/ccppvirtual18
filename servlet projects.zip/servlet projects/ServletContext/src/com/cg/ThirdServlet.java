package com.cg;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ThirdServlet extends HttpServlet{
	
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		PrintWriter out = response.getWriter();
		
		
		   
					out.println("<html><body><h2>");
					out.println("<form action=\"FourthServlet\" >");
					ServletContext anitha = getServletContext();
					String firstname= (String) anitha.getAttribute("firstname");
					String lastname= (String) anitha.getAttribute("lastname");
					String state=request.getParameter("state");
					String city=request.getParameter("city");
					
					out.println("Firstname :"+firstname+"<br>");
					out.println("Lastname :"+lastname+"<br>");
					out.println("State :"+state+"<br>");
					out.println("City :"+city+"<br>");
					out.println("phone.no <input name=\"phone\" type=\"text\"><br>");
					out.println("email-id <input name=\"email\" type=\"text\"><br>");
					out.println("<input type=\"submit\">");
					out.println("</form></h2></body></html>"); 
					anitha.setAttribute("state",state);
					anitha.setAttribute("city",city);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request,response);

	  }
}
